import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';

@Component({
  selector: 'app-password-gen',
  templateUrl: './password-gen.component.html',
  styleUrls: ['./password-gen.component.css']
})
export class PasswordGenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  @ViewChild("check") chk1: ElementRef;
  // check 
  check1: any;
  
  ngAfterViewChecked() {
    console.log("in after", this.chk1);
    //  this.chk1.nativeElement.checked=true;
    if (this.chk1.nativeElement.checked) {
      console.log("checked");

    }


  }
  generatePassword() {

  }
  checkBox() {
    if (this.chk1.nativeElement.checked) {
      console.log("checked");

    }
    console.log("in box", this.chk1.nativeElement.checked)
    console.log("check model",this.check1);
    

  }

}
