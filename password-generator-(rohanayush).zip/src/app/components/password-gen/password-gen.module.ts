import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PasswordGenComponent } from './password-gen.component';
import { FormsModule } from '@angular/forms';



@NgModule({
  declarations: [
    PasswordGenComponent
  ],
  imports: [
    CommonModule,
    FormsModule
  ]
})
export class PasswordGenModule { }
