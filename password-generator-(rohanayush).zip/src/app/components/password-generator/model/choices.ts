export interface Choices{
    length:number,
    alphabets:boolean,
    numbers:boolean,
    special:boolean
}